module Main where

import Data.HashSet
import Data.List (find, partition, transpose)
import Data.List.Split (splitOn)
import Debug.Trace (traceShowId)
import System.Environment (getArgs)

type Point = (Int, Int)

type VentLine = (Point, Point)

-- Parse a line of input as a vent line
parseLine :: String -> VentLine
parseLine inputLine =
  let pairs = map (splitOn ",") (splitOn " -> " inputLine)
   in case pairs of
        [[x1, y1], [x2, y2]] -> ((read x1, read y1), (read x2, read y2))
        _ -> error "not a valid vent line!"

countCollisions :: HashMap Point -> [VentLine] -> Int
countCollisions collisions [] = length

-- Part 1: find number of points where at least two horizontal or vertical lines cross
part1 :: [VentLine] -> Int
part1 ventLines = 0

-- Part 2: ?
part2 :: [VentLine] -> Int
part2 ventLines = 0

main :: IO ()
main = do
  (filename : _) <- getArgs
  contents <- readFile filename
  let inputLines = lines contents
      ventLines = map parseLine inputLines

  print $ part1 ventLines
  print $ part2 ventLines
